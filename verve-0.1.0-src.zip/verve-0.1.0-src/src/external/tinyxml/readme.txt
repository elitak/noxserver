Using TinyXML version 2.4.2 released on 10-19-2005.

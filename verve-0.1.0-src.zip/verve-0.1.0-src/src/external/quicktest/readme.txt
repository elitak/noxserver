Using Quicktest version 1.0.0 released on 7-21-2005.

#include <quicktest/quicktest.h>
#include "../../../src/StaticConnection.h"
#include "../../../src/Neuron.h"


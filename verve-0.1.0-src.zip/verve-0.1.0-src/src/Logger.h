/************************************************************************
* Verve                                                                 *
* Copyright (C) 2004-2006                                               *
* Tyler Streeter  tylerstreeter@gmail.com                               *
* All rights reserved.                                                  *
* Web: http://verve-agents.sourceforge.net                              *
*                                                                       *
* This library is free software; you can redistribute it and/or         *
* modify it under the terms of EITHER:                                  *
*   (1) The GNU Lesser General Public License as published by the Free  *
*       Software Foundation; either version 2.1 of the License, or (at  *
*       your option) any later version. The text of the GNU Lesser      *
*       General Public License is included with this library in the     *
*       file license-LGPL.txt.                                          *
*   (2) The BSD-style license that is included with this library in     *
*       the file license-BSD.txt.                                       *
*                                                                       *
* This library is distributed in the hope that it will be useful,       *
* but WITHOUT ANY WARRANTY; without even the implied warranty of        *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the files    *
* license-LGPL.txt and license-BSD.txt for more details.                *
************************************************************************/

#ifndef VERVE_LOGGER_H
#define VERVE_LOGGER_H

#include <iomanip>
#include <stdlib.h>
#include <string>
#include <ostream>
#include <iostream>
#include <map>
#include <iosfwd>
#include <stdexcept>

/// Use this macro to access the Logger singleton.  For example, 
/// VERVE_LOGGER("debug") << errorMsg << std::endl;
#define VERVE_LOGGER Logger::instance().stream

namespace verve
{
	///	This class is used to log any events, errors, or warnings that 
	/// may come up.  Calls to this class should replace all 
	/// cout << statements in the form: 
	///    Logger::stream("myStreamName") << ...
	///	where myStreamName was registered as a cout stream or file 
	/// stream using the setStream function.
	/// We use a singleton here so we never have to initialize the 
	/// Logger explicitly.
	class Logger
	{
	public:
		/// Returns a reference to the singleton.  
		static Logger& VERVE_CALL instance()
		{
			static Logger mSelf;
			return mSelf;
		}

		/// Register a new stream for later use.
		void VERVE_CALL setStream(const std::string& name, 
			std::ostream *stream, const std::string& prefix="", 
			char mark='\0')
		{
			Logger::Stream s;
			s.mark = mark;
			s.silent = false;
			s.stream = stream;
			s.prefix = prefix;
			mStreams[name] = s;
		}

		/// Returns the named stream.
		std::ostream& VERVE_CALL stream(const std::string& name)
		{
			Logger::Stream s = mStreams[name];

			if(s.mark != '\0')
			{
				std::cout << s.mark;
				std::cout.flush();
			}

			if (!s.prefix.empty())
			{
				*s.stream << s.prefix;
			}

			return *(s.stream);
		}

	private:
		Logger()
		{
			setStream("debug", &std::cout, "[Verve debug] ");
			setStream("warning", &std::cout, "[Verve warning] ");
			setStream("error", &std::cout, "[Verve error] ");
		}

		~Logger()
		{
		}

		/// A simple output stream structure.
		struct Stream
		{
			std::ostream *nullStream;
			std::ostream *stream;
			bool silent;
			char mark;
			std::string prefix;
		};

		/// Internal map of named output streams.
		std::map<std::string, Stream> mStreams;
	};
}

#endif

/************************************************************************
* Verve                                                                 *
* Copyright (C) 2004-2006                                               *
* Tyler Streeter  tylerstreeter@gmail.com                               *
* All rights reserved.                                                  *
* Web: http://verve-agents.sourceforge.net                              *
*                                                                       *
* This library is free software; you can redistribute it and/or         *
* modify it under the terms of EITHER:                                  *
*   (1) The GNU Lesser General Public License as published by the Free  *
*       Software Foundation; either version 2.1 of the License, or (at  *
*       your option) any later version. The text of the GNU Lesser      *
*       General Public License is included with this library in the     *
*       file license-LGPL.txt.                                          *
*   (2) The BSD-style license that is included with this library in     *
*       the file license-BSD.txt.                                       *
*                                                                       *
* This library is distributed in the hope that it will be useful,       *
* but WITHOUT ANY WARRANTY; without even the implied warranty of        *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the files    *
* license-LGPL.txt and license-BSD.txt for more details.                *
************************************************************************/

#ifndef OPAL_OGRE_ENGINE_H
#define OPAL_OGRE_ENGINE_H

#include "PhysicalEntity.h"
#include "PhysicalCamera.h"

/// Various ways to update the simulation.
enum UpdateMode
{
	/// Each update simulates the world ahead by a constant amount of time.
	SIMULATE_CONSTANT_CHUNK,

	/// Each update simulates the world ahead by an amount of time 
	/// proportional to the elapsed time since the previous update.
	SIMULATE_REAL_TIME_MULTIPLE
};

class OpalOgreEngine
{
public:
	OpalOgreEngine();

	~OpalOgreEngine();

	/// Sets up Ogre and Opal.  If 'simulationOnly' is true, a graphics 
	/// windows (and input device) will not be created.  Returns false if 
	/// we should quit.
	bool init(bool simulationOnly = false);

	/// Updates input, physics, and graphics.  Returns the amount of time 
	/// by which the world was just simulated (which depends on the 
	/// UpdateType being used).
	Ogre::Real update();

	/// Returns true if we should quit the app.  This should be checked 
	/// after each update.
	bool quitApp();

	/// Returns a pointer to the Opal Simulator.
	opal::Simulator* getSimulator()const;

	/// Returns a pointer to the Ogre SceneManager.
	Ogre::SceneManager* getSceneManager()const;

	/// Sets the type of update to use.  The extra real parameter is used 
	/// for the constant amount of time to simulate in seconds (for 
	/// SIMULATE_CONSTANT_CHUNK mode) or for the multiple of the actual 
	/// elapsed time (for SIMULATE_REAL_TIME_MULTIPLE mode).  The constant 
	/// must be greater than zero.
	void setUpdateMode(UpdateMode type, Ogre::Real updateConstant);

	/// Sets whether frames should be captured after each update and 
	/// saved to files.  This is useful for making videos, for example.  
	/// It is recommended that the update mode be SIMULATE_CONSTANT_CHUNK 
	/// when capturing frames.  Also, note that the runtime performance 
	/// will probably decrease substantially as frames are being captured.
	void setCaptureFramesEnabled(bool capture);

	/// Creates and returns a pointer to a PhysicalEntity.  Takes 
	/// the name of the new PhysicalEntity, the associated Ogre 
	/// SceneNode, and a pointer to an OPAL Solid.  If the name string 
	/// is empty, a unique name will be automatically generated; 
	/// otherwise, the given name must be unique.
	PhysicalEntity* createPhysicalEntity(const std::string& name, 
		Ogre::SceneNode* sn, opal::Solid* s);

	/// Creates a PhysicalEntity drawn as a box.  The OPAL Solid can 
	/// be any shape, however.  This is useful for prototyping scenes 
	/// when you don't have a specific visual mesh to use.  If the name 
	/// string is empty, a unique name will be automatically generated; 
	/// otherwise, the given name must be unique.
	PhysicalEntity* createPhysicalEntityBox(const std::string& name, 
		const std::string& materialName, Ogre::Vector3 dimensions, 
		opal::Solid* s);

	/// Creates a PhysicalEntity drawn as a sphere.  The OPAL Solid can 
	/// be any shape, however.  This is useful for prototyping scenes 
	/// when you don't have a specific visual mesh to use.  If the name 
	/// string is empty, a unique name will be automatically generated; 
	/// otherwise, the given name must be unique.
	PhysicalEntity* createPhysicalEntitySphere(const std::string& name, 
		const std::string& materialName, Ogre::Real radius, 
		opal::Solid* s);

	/// Creates a PhysicalEntity drawn as a capsule.  The OPAL Solid can 
	/// be any shape, however.  This is useful for prototyping scenes 
	/// when you don't have a specific visual mesh to use.  If the name 
	/// string is empty, a unique name will be automatically generated; 
	/// otherwise, the given name must be unique.
	PhysicalEntity* createPhysicalEntityCapsule(const std::string& name, 
		const std::string& materialName, Ogre::Real radius, 
		Ogre::Real length, opal::Solid* s);

	/// Finds a PhysicalEntity pointer by name.  Returns NULL if the 
	/// PhysicalEntity could not be found.
	PhysicalEntity* getPhysicalEntity(const std::string& name)const;

	/// Destroys the given PhysicalEntity.
	void destroyPhysicalEntity(PhysicalEntity* pe);

	/// Destroys all of the PhysicalEntities.
	void destroyAllPhysicalEntities();

protected:
	/// Initial scene setup function.  Create and position lights, setup 
	/// shadows, etc.
	void setupDefaultScene();

	/// Updates the picking graphics.
	void updatePickingGraphics();

	/// Saves the current screen to a file with a unique name.
	void captureFrame();

	/// Returns false if we should break out of the main loop.
	bool handleInput(Ogre::Real dt);

	/// Process keyboard input here.  Returns false if we should break out 
	/// of the main loop.
	bool processUnbufferedKeyInput(Ogre::Real dt);

	/// Process mouse input here.  Returns false if we should break out of 
	/// the main loop.
	bool processUnbufferedMouseInput(Ogre::Real dt);

	/// Updates the Ogre stats overlay.
	void updateOgreStats();

	/// Returns a unique name string.  Useful when creating lots of 
	/// anonymous objects.
	std::string generateUniqueName();

	/// Pointer to the Ogre root object.
	Ogre::Root *mOgreRoot;

	/// Pointer to the Ogre scene manager.
	Ogre::SceneManager* mOgreSceneMgr;

	/// Pointer to the Ogre window object.
	Ogre::RenderWindow* mOgreWindow;

	/// Pointer to the Ogre overlay object.
	Ogre::Overlay* mDebugOverlay;

	/// Pointer to the input device.
	Ogre::InputReader* mInputDevice;

	/// Pointer to the OPAL Simulator.
	opal::Simulator* mSimulator;

	/// Pointer to the PhysicalCamera.
	PhysicalCamera* mPhysicalCamera;

	/// Determines how fast the camera can translate.
	Ogre::Real mCameraMoveSpeed;

	/// Determines how fast the camera can rotate.
	Ogre::Degree mCameraRotateSpeed;

	/// A timer used to measure time differences between frames.
	Ogre::Timer mFrameTimer;

	/// Set to true when the app should quit.
	bool mQuitApp;

	/// True when the physics simulation is paused.
	bool mPaused;

	/// The type of update being used.
	UpdateMode mUpdateMode;

	/// A constant value used along with the update mode.
	Ogre::Real mUpdateConstant;

	/// Determines whether frames are captured after each update.
	bool mCaptureFramesEnabled;

	/// Used to prevent key toggles from happening to fast.
	Ogre::Real mTimeUntilNextToggle;

	/// Map of named PhysicalEntities.  This is just used to find a 
	/// PhysicalEntity by name.
	std::vector<PhysicalEntity*> mPhysicalEntityList;

	/// Map of named PhysicalEntities.
	std::map<std::string, PhysicalEntity*> mPhysicalEntityMap;

private:
};

#endif
